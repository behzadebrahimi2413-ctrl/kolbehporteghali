const db = {
  bookings: [],
  payments: [],
  blockedDates: []
}

let bookingId = 1
let paymentId = 1

export function createBooking(b) {
  const id = bookingId++
  const record = { id, status: 'pending', created_at: new Date().toISOString(), ...b }
  db.bookings.push(record)
  return record
}

export function getBooking(id) { return db.bookings.find(x => x.id === Number(id)) }
export function listBookings() { return db.bookings }

export function createPayment(p) {
  const id = paymentId++
  const record = { id, status: 'initiated', created_at: new Date().toISOString(), ...p }
  db.payments.push(record)
  return record
}

export function updatePayment(id, patch) {
  const p = db.payments.find(x => x.id === Number(id)); Object.assign(p, patch); return p
}

export function confirmBooking(bookingId) {
  const b = getBooking(bookingId)
  if (!b) return null
  b.status = 'confirmed'
  const sd = new Date(b.start_date)
  const ed = new Date(b.end_date)
  for (let d = new Date(sd); d < ed; d.setDate(d.getDate()+1)) {
    db.blockedDates.push({ propertyId: 1, date: d.toISOString().slice(0,10) })
  }
  return b
}

export function listBlockedDates() { return db.blockedDates }
