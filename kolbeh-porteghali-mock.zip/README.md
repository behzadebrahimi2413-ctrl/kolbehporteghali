Kolbeh Porteghali — Mock (Test-only)
===================================

This package is a minimal Next.js MVP for local testing. Payment is simulated (no real gateway keys required).

How to run:
1. Ensure Node.js >=16 is installed.
2. In project folder:
   npm install
   npm run dev
3. Open http://localhost:3000
4. Create a booking and click 'Simulate payment' to confirm.

Notes:
- Data is stored in memory and will reset when the server restarts.
- Invoice feature is not included in this package (placeholder page exists).
