import Head from 'next/head'
import { useState, useEffect } from 'react'
import { useI18n } from '../utils/i18n'
import BookingForm from '../components/BookingForm'
import CalendarView from '../components/CalendarView'

export default function Home() {
  const { t, lang, setLang } = useI18n()
  const [blocked, setBlocked] = useState([])

  useEffect(() => { fetch('/api/blocked').then(r=>r.json()).then(d=>setBlocked(d)) }, [])

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <Head>
        <title>{t('title')}</title>
      </Head>

      <header className="max-w-4xl mx-auto flex justify-between items-center mb-6">
        <div>
          <h1 className="text-3xl font-bold">{t('title')}</h1>
          <p className="text-sm text-gray-600">{t('subtitle')}</p>
        </div>
        <div>
          <select value={lang} onChange={e=>setLang(e.target.value)} className="border p-2 rounded">
            <option value="fa">فارسی</option>
            <option value="en">English</option>
          </select>
        </div>
      </header>

      <main className="max-w-4xl mx-auto grid grid-cols-1 md:grid-cols-2 gap-6">
        <section className="bg-white p-4 rounded shadow">
          <img src="/villa.jpg" alt="کلبه پرتقالی" className="w-full h-44 object-cover rounded mb-4" />
          <h2 className="text-xl font-semibold mb-2">{t('subtitle')}</h2>
          <p className="text-gray-700 mb-4">کلبه سوییسی، دسترسی خصوصی، فضای باز 1200 متر، مناسب برای استراحت و دوری از شلوغی شهر.</p>
          <p className="text-sm text-gray-500">{t('invoiceNote')}</p>
        </section>

        <section className="bg-white p-4 rounded shadow">
          <BookingForm />
        </section>

        <section className="col-span-1 md:col-span-2 bg-white p-4 rounded shadow">
          <h3 className="font-semibold mb-2">تقویم رزروها</h3>
          <CalendarView blockedDates={blocked} />
        </section>
      </main>
    </div>
  )
}
