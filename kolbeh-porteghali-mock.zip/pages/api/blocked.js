import { listBlockedDates } from '../../data/store'

export default function handler(req, res) {
  const b = listBlockedDates()
  return res.json(b)
}
