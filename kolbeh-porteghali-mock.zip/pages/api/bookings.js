import { createBooking } from '../../data/store'

export default function handler(req, res) {
  if (req.method === 'POST') {
    const { start_date, end_date, guests } = req.body
    if (!start_date || !end_date) return res.status(400).json({ error: 'missing dates' })
    const booking = createBooking({ start_date, end_date, guests })
    return res.status(201).json(booking)
  }
  return res.status(405).end()
}
