import { updatePayment, confirmBooking } from '../../../data/store'

export default async function handler(req, res) {
  const body = req.method === 'GET' ? req.query : req.body
  const { paymentId, bookingId, status } = body
  if (!paymentId || !bookingId) return res.status(400).json({ error: 'missing' })
  updatePayment(paymentId, { status })
  if (status === 'success') {
    confirmBooking(bookingId)
  }
  return res.json({ ok: true })
}
