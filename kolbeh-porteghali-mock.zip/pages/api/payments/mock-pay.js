export default function handler(req, res) {
  const { paymentId, bookingId } = req.query
  res.send(`
    <html><body>
      <h3>Mock Payment Page</h3>
      <p>Payment ID: ${paymentId}</p>
      <p>Booking ID: ${bookingId}</p>
      <form method="POST" action="/api/payments/webhook">
        <input type="hidden" name="paymentId" value="${paymentId}" />
        <input type="hidden" name="bookingId" value="${bookingId}" />
        <input type="hidden" name="status" value="success" />
        <button type="submit">Simulate Success</button>
      </form>
    </body></html>
  `)
}
