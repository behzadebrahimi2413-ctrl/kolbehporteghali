import { createPayment } from '../../../data/store'

export default function handler(req, res) {
  if (req.method === 'POST') {
    const { bookingId, gateway } = req.body
    const p = createPayment({ bookingId, gateway, amount: 100 })
    return res.json({ paymentId: p.id, paymentLink: `/api/payments/mock-pay?paymentId=${p.id}&bookingId=${bookingId}` })
  }
  res.status(405).end()
}
