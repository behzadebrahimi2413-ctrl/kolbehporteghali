import { useRouter } from 'next/router'
export default function InvoicePage(){
  const { query } = useRouter()
  return (
    <div className="p-6">
      <h2 className="text-2xl">صفحهٔ فاکتور (به‌زودی)</h2>
      <p>رزرو: {query.id}</p>
      <p>قابلیت صدور فاکتور در نسخهٔ بعدی اضافه خواهد شد.</p>
    </div>
  )
}
