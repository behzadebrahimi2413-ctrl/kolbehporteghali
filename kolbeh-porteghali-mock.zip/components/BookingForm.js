import { useState } from 'react'
import { useI18n } from '../utils/i18n'

export default function BookingForm() {
  const { t } = useI18n()
  const [start, setStart] = useState('')
  const [end, setEnd] = useState('')
  const [guests, setGuests] = useState(2)
  const [status, setStatus] = useState(null)
  const [booking, setBooking] = useState(null)

  async function handleReserve(e) {
    e.preventDefault()
    setStatus('creating')
    const res = await fetch('/api/bookings', { method: 'POST', headers: {'Content-Type':'application/json'}, body: JSON.stringify({ start_date: start, end_date: end, guests }) })
    const data = await res.json()
    setBooking(data)
    setStatus('created')
  }

  async function createPayment() {
    setStatus('payment')
    const res = await fetch('/api/payments/create', { method: 'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({ bookingId: booking.id, gateway: 'mock' }) })
    const data = await res.json()
    setStatus('awaiting_payment')
  }

  async function simulatePaymentSuccess() {
    const res = await fetch('/api/payments/webhook', { method: 'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({ paymentId: 1, bookingId: booking.id, status: 'success' }) })
    const d = await res.json()
    setStatus('confirmed')
    fetch('/api/blocked').then(r=>r.json()).then(d=>console.log('blocked',d))
  }

  return (
    <div>
      <form onSubmit={handleReserve} className="space-y-3">
        <div>
          <label className="block text-sm">{t('startDate')}</label>
          <input required value={start} onChange={e=>setStart(e.target.value)} type="date" className="w-full border p-2 rounded" />
        </div>
        <div>
          <label className="block text-sm">{t('endDate')}</label>
          <input required value={end} onChange={e=>setEnd(e.target.value)} type="date" className="w-full border p-2 rounded" />
        </div>
        <div>
          <label className="block text-sm">{t('guests')}</label>
          <input type="number" min={1} value={guests} onChange={e=>setGuests(e.target.value)} className="w-full border p-2 rounded" />
        </div>

        {status === 'creating' ? (
          <button className="w-full p-2 bg-gray-300 rounded">در حال ایجاد...</button>
        ) : (
          <button type="submit" className="w-full p-2 bg-blue-600 text-white rounded">{t('reserve')}</button>
        )}
      </form>

      {status === 'created' && (
        <div className="mt-4 p-3 border rounded bg-green-50">
          <p>رزرو ایجاد شد (ID: {booking.id}). حالا پرداخت را شبیه‌سازی کنید.</p>
          <div className="mt-2 flex gap-2">
            <button onClick={createPayment} className="px-3 py-2 bg-yellow-500 rounded">{t('pay')}</button>
            <button onClick={simulatePaymentSuccess} className="px-3 py-2 bg-green-600 text-white rounded">{t('simulatePayment')}</button>
          </div>
        </div>
      )}

      {status === 'confirmed' && (
        <div className="mt-4 p-3 border rounded bg-blue-50">
          <p>پرداخت با موفقیت انجام شد — رزرو تایید شد.</p>
        </div>
      )}
    </div>
  )
}
