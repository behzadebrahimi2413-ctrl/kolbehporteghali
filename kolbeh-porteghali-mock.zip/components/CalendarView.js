import { useEffect, useState } from 'react'
import { format, parseISO } from 'date-fns'

export default function CalendarView({ blockedDates=[] }) {
  const [days, setDays] = useState([])

  useEffect(()=>{
    const arr = []
    const today = new Date()
    for (let i=0;i<30;i++){
      const d = new Date(today); d.setDate(today.getDate()+i)
      const iso = d.toISOString().slice(0,10)
      arr.push({ iso, blocked: blockedDates.includes(iso) || blockedDates.some(b=>b.date===iso) })
    }
    setDays(arr)
  }, [blockedDates])

  return (
    <div className="grid grid-cols-7 gap-2">
      {days.map(d=> (
        <div key={d.iso} className={`p-2 border rounded text-center ${d.blocked ? 'bg-red-200 text-red-800' : 'bg-white'}`}>
          <div className="text-sm">{format(parseISO(d.iso),'dd/MM')}</div>
          <div className="text-xs">{d.blocked ? 'رزرو شده' : 'آزاد'}</div>
        </div>
      ))}
    </div>
  )
}
