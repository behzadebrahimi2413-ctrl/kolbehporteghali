import React, { createContext, useContext, useState } from 'react'

const translations = {
  fa: {
    title: 'کلبه پرتقالی',
    subtitle: 'کلبه سوییسی در بافت روستایی — دربست، محیط 1200 متر',
    reserve: 'رزرو کن',
    checkAvailability: 'بررسی در دسترس بودن',
    guests: 'تعداد مهمان',
    startDate: 'تاریخ ورود',
    endDate: 'تاریخ خروج',
    pay: 'پرداخت',
    simulatePayment: 'شبیه‌سازی پرداخت (تست)',
    invoiceNote: 'صدور فاکتور در نسخهٔ بعدی فعال می‌شود.'
  },
  en: {
    title: 'Kolbeh Porteghali',
    subtitle: 'Swiss-style cottage in rural village — full-booking, 1200 sqm',
    reserve: 'Book now',
    checkAvailability: 'Check availability',
    guests: 'Guests',
    startDate: 'Start date',
    endDate: 'End date',
    pay: 'Pay',
    simulatePayment: 'Simulate payment (test)',
    invoiceNote: 'Invoice feature will be added later.'
  }
}

const I18nContext = createContext()

export function I18nProvider({ children }) {
  const [lang, setLang] = useState('fa')
  const t = (k) => translations[lang][k] || k
  return (
    <I18nContext.Provider value={{ lang, setLang, t }}>
      {children}
    </I18nContext.Provider>
  )
}

export function useI18n() {
  return useContext(I18nContext)
}
